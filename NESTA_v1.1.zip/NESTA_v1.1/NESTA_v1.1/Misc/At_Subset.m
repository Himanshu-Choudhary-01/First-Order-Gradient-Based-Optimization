function y = At_Subset(x,n,Omega);

y = zeros(n,1);
y(Omega) =x;

